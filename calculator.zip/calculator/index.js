

const display = document.getElementById("display");

function appendToDisplay(input){
    display.value+=input;


}

function clearDisplay(){
    display.value ="";


}

function calculate(){
    try {
        // Enhanced calculation logic
        const result = eval(display.value);
    
        // Rounding options
        if (!Number.isInteger(result)) { 
          // Only round if the result is a decimal
          display.value = roundToFiveDecimals(result); 
        } else {
          display.value = result; // Keep integers as they are
        }
      } catch (error) {
        display.value = "Error";
      }
    }
    
    // Reusable rounding function
    function roundToFiveDecimals(number) {
      return Number(number.toFixed(5));

   

    
}